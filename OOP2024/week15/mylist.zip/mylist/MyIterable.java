package hus.oop.mylist;

public interface MyIterable {
    MyIterator iterator();
}
