package hus.oop.midterm.books;

public interface BookComparable {
    int compareTo(Book another);
}
