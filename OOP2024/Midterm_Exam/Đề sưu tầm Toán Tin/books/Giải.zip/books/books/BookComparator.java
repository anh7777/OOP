package hus.oop.midterm.books;

import java.util.Comparator;

public interface BookComparator {
    int compare(Book left, Book right);
}
