package oop.hus.exe1.exe12;

public interface GeometricObject {
    double getArea();
    double getPerimeter();
}
