package oop.hus.exe1.exe14;

interface Movable {
    void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
}
