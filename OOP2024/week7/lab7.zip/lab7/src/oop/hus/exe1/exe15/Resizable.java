package oop.hus.exe1.exe15;

interface Resizable {
    void resize(int percent);
}
