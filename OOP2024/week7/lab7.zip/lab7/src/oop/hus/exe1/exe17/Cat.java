package oop.hus.exe1.exe17;

public class Cat extends Animal {
    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}
