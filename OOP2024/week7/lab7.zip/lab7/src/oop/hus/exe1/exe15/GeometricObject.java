package oop.hus.exe1.exe15;

public interface GeometricObject {
    double getArea();
    double getPerimeter();
}
