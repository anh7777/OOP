package oop.hus.exe1.exe17;

abstract class Animal {
    public abstract void greeting();
}
