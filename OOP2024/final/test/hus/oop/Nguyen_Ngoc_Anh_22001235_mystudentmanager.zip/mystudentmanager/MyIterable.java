package hus.oop.mystudentmanager;

public interface MyIterable {
    MyIterator iterator();
}
