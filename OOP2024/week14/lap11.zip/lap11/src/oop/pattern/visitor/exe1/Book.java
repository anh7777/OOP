package oop.pattern.visitor.exe1;

interface Book {
    void accept(Visitor v);
}
