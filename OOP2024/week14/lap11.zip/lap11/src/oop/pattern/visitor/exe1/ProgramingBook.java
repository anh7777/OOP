package oop.pattern.visitor.exe1;

interface ProgramingBook extends Book {
    String getResource();
}
