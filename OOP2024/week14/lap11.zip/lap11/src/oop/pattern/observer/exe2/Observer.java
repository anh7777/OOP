package oop.pattern.observer.exe2;

public abstract class Observer {
    protected Subject subject;
    public abstract void update();
}