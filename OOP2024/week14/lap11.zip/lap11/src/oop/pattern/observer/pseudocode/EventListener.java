package oop.pattern.observer.pseudocode;

interface EventListener {
    void update(String fileName);
}
