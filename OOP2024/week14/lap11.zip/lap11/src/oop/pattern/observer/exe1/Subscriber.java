package oop.pattern.observer.exe1;

interface Subscriber {
    void update(Object context);
}
