package oop.pattern.iterator.exe3.employee;
import java.util.Iterator;

public interface EmployeeIterable {
    Iterator<String> getIterator();
}