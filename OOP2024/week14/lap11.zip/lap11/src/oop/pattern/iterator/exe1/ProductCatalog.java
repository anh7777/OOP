package oop.pattern.iterator.exe1;

public interface ProductCatalog {
    Iterator getIterator();
}
