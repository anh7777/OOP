package oop.pattern.iterator.exe3.cafe;

interface Menu {
    Iterator createIterator();
}