package oop.pattern.iterator.exe1;

public interface Iterator {
    boolean hasNext();
    Object next();
}
