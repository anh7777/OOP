package oop.pattern.iterator.exe2;

interface ProfileIterator {
    Profile getNext();
    boolean hasMore();
}