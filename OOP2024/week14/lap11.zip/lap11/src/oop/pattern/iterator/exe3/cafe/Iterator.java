package oop.pattern.iterator.exe3.cafe;

interface Iterator {
    boolean hasNext();
    Object next();
}