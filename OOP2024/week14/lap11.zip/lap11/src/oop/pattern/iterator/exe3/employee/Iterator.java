package oop.pattern.iterator.exe3.employee;

interface Iterator {
    boolean hasNext();
    Object next();
}