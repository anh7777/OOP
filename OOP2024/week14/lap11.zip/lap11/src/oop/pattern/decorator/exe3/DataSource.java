package oop.pattern.decorator.exe3;

public interface DataSource {
    void writeData(String data);
    String readData();
}
