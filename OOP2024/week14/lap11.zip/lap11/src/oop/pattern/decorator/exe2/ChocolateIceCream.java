package oop.pattern.decorator.exe2;

public class ChocolateIceCream implements IceCream {
    @Override
    public String getDescription() {
        return "Chocolate Ice Cream";
    }
}
