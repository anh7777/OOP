package oop.pattern.decorator.exe2;

interface IceCream {
    String getDescription();
}
