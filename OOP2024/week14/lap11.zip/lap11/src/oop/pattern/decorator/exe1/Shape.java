package oop.pattern.decorator.exe1;

public interface Shape {
    void draw();
}
