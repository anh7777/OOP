package oop.pattern.decorator.examples.structure;

public abstract class AbstractComponent {
    public abstract void operation();
}
