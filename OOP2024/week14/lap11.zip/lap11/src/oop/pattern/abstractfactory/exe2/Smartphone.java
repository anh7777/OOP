package oop.pattern.abstractfactory.exe2;

public interface Smartphone {
    void displayInfo();
}
