package oop.pattern.abstractfactory.exe1;

public class WinButton implements Button {
    public void paint() {
        System.out.println("Win Button");
    }
}
