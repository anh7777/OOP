package oop.pattern.abstractfactory.exe2;

public interface Laptop {
    void displayInfo();
}
