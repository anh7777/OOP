package oop.pattern.abstractfactory.exe1;

public interface Checkbox {
    void paint();
}
