package oop.pattern.abstractfactory.exe2;

public class AppleSmartphone implements Smartphone {
    public void displayInfo() {
        System.out.println("This is an Apple smartphone.");
    }
}
