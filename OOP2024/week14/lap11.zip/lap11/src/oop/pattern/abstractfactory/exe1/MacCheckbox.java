package oop.pattern.abstractfactory.exe1;

public class MacCheckbox implements Checkbox {
    public void paint() {
        // Render a checkbox in macOS style.
    }
}
