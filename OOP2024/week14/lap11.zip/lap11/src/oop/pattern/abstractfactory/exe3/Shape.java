package oop.pattern.abstractfactory.exe3;

public interface Shape {
    void draw();
}
