package oop.pattern.abstractfactory.exe1;

public interface Button {
    void paint();
}
