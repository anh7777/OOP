package oop.pattern.abstractfactory.exe2;

public class AppleLaptop implements Laptop {
    public void displayInfo() {
        System.out.println("This is an Apple laptop.");
    }
}
