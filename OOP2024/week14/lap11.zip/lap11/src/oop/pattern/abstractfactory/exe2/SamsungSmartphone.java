package oop.pattern.abstractfactory.exe2;

public class SamsungSmartphone implements Smartphone {
    public void displayInfo() {
        System.out.println("This is a Samsung smartphone.");
    }
}
