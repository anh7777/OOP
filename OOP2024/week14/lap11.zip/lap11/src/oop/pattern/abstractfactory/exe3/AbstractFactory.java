package oop.pattern.abstractfactory.exe3;

public interface AbstractFactory {
    Shape getShape();
}
