package oop.pattern.abstractfactory.exe1;

public class Configuration {
    String OS;

    public Configuration(String OS) {
        this.OS = OS;
    }
}
