package oop.pattern.factorymethod.exe3;

public interface Fruit {
    void produceJuice();
}
