package oop.pattern.factorymethod.exe2;

public abstract class BasePizzaFactory {
    public abstract Pizza createPizza(String type);
}