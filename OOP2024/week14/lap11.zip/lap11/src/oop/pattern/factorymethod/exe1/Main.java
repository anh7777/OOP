package oop.pattern.factorymethod.exe1;

public class Main {
    public static void main(String[] args) throws Exception {
        Application app = new Application();
        app.main();
    }
}
