package oop.pattern.factorymethod.exe1;

class Config {
    String OS;

    public Config(String OS) {
        this.OS = OS;
    }
}
