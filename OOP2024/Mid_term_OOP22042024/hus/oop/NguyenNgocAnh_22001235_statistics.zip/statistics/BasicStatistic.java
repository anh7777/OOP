package hus.oop.statistics;

public class BasicStatistic implements Statistic {
    private DataSet dataSet;

    /**
     * Hàm dựng khởi tạo tập dữ liệu.
     */
    public BasicStatistic() {
        /* TODO */
    }

    public void setDataSet(DataSet dataSet) {
        /* TODO */
        this.dataSet = dataSet;
    }

    @Override
    public int size() {
        /* TODO */
        return dataSet.size();
    }

    @Override
    public double max() {
        /* TODO */
        double maxData = 0;
        for (double e: dataSet.elements(0, dataSet.size() - 1)) {
            if (e > maxData) {
                maxData = e;
            }
        }
        return maxData;
    }

    @Override
    public double min() {
        /* TODO */
        double minData = dataSet.elementAt(0);
        for (double e: dataSet.elements(1, dataSet.size() - 1)) {
            if (e < minData) {
                minData = e;
            }
        }
        return minData;
    }

    @Override
    public double mean() {
        /* TODO */
        double sumData = 0;
        for (double e: dataSet.elements(0, dataSet.size() - 1)) {
            sumData += e;
        }
        return sumData / dataSet.size();
    }

    @Override
    public double variance() {
        /* TODO */
        double x = 0;
        for (double e: dataSet.elements(0, dataSet.size() - 1)) {
            x += Math.pow(e - mean(), 2);
        }
        return x / dataSet.size();
    }

    @Override
    public double[] rank() {
        /* TODO */
        return dataSet.elements(0, dataSet.size() - 1);
    }

    @Override
    public double median() {
        /* TODO */
        double[] rank = rank();
        if (rank.length % 2 == 0) {
            return rank[(rank.length / 2) - 1];
        }
        return 0;
    }
}
