package hus.oop.statistics;

public class ArrayDataSet extends AbstractDataSet {
    private static final int DEFAULT_CAPACITY = 8;
    private double[] data;
    private int size;

    /**
     * Hàm dựng để khởi tạo dữ liệu.
     */
    public ArrayDataSet() {
        /* TODO */
    }

    @Override
    public int size() {
        /* TODO */
        return size;
    }

    @Override
    public double elementAt(int index) {
        /* TODO */
        return data[index];
    }

    @Override
    public double[] elements(int from, int to) {
        /* TODO */
        double[] result = new double[to - from];
        System.arraycopy(data, from, result, 0, to - from);
        return result;
    }

    /**
     * Thêm phần tử dữ liệu vào đầu mảng dữ liệu.
     * Nếu mảng không còn chỗ, mở rộng mảng để có thể chứa thêm dữ liệu.
     * @param value giá trị của phần tử dữ liệu được thêm vào.
     */
    @Override
    public void insertAtStart(double value) {
        /* TODO */
        if (this.size == this.data.length) {
            this.allocateMore();
        }
        double[] newdata = new double[this.data.length];
        newdata[0] = value;
        System.arraycopy(data, 0, newdata, 1, this.size);
        this.data = newdata;
    }

    /**
     * Thêm phần tử dữ liệu vào cuối mảng dữ liệu.
     * Nếu mảng không còn chỗ, mở rộng mảng để có thể chứa thêm dữ liệu.
     * @param value giá trị của phần tử dữ liệu được thêm vào.
     */
    @Override
    public void insertAtEnd(double value) {
        /* TODO */
        if (this.size == this.data.length) {
            this.allocateMore();
        }

        this.data[this.size++] = value;
    }

    /**
     * Thêm phần tử dữ liệu vào vị trí index của mảng dữ liệu.
     * Nếu mảng không còn chỗ, mở rộng mảng để có thể chứa thêm dữ liệu.
     * @param index
     * @param value
     */
    @Override
    public void insertAtPosition(int index, double value) {
        /* TODO */
        if (index >= 0 && index < this.size) {
            if (this.size == this.data.length) {
                this.allocateMore();
            }

            for(int i = this.size; i > index; --i) {
                this.data[i] = this.data[i - 1];
            }

            this.data[index] = value;
            ++this.size;
        } else {
            throw new IndexOutOfBoundsException();
        }
    }

    /**
     * Xóa phần tử dữ liệu tại vị trí index.
     * @param index
     */
    @Override
    public void remove(int index) {
        /* TODO */
        if (index >= 0 && index < this.size) {
            for(int i = index; i < this.size - 1; ++i) {
                this.data[i] = this.data[i + 1];
            }

            --this.size;
        } else {
            throw new IndexOutOfBoundsException();
        }
    }

    /**
     * Xóa tất cả các phần tử dữ liệu có giá trị bằng value.
     * @param value
     */
    @Override
    public void remove(double value) {
        /* TODO */
        for (int i = this.size - 1; i >= 0; --i) {
            if (this.data[i] == value) {
                remove(data[i]);
            }
        }
    }

    /**
     * Mở rộng gấp đôi kích thước mảng nếu hết chỗ để chứa dữ liệu.
     */
    private void allocateMore() {
        /* TODO */
        int newCapacity = this.data.length * 2;
        double[] newData = new double[newCapacity];
        System.arraycopy(this.data, 0, newData, 0, this.data.length);
        this.data = newData;
    }
}
