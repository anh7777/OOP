package hus.oop.statistics;

public abstract class AbstractDataSet implements DataSet {
    /**
     * Mô tả tập dữ liệu.
     * @return mô tả tập dữ liệu dạng [a1, a2, a3, ..., an].
     */
    @Override
    public String toString() {
        /* TODO */
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        sb.append(elementAt(0));

        for(double e: elements(1, size() - 1)) {
            sb.append(e).append(", ");
        }
        sb.append(elementAt(size() - 1)).append("]");
        return sb.toString();
    }
}
