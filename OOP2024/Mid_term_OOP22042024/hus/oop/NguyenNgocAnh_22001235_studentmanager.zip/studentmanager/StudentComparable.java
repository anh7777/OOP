package hus.oop.studentmanager;

public interface StudentComparable {
    int compareTo(Student another);
}
