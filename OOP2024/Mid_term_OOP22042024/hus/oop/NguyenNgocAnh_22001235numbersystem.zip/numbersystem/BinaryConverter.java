package hus.oop.numbersystem;

public class BinaryConverter extends AbstractNumberConverter {
    public BinaryConverter(OriginalNumber originalNumber) {
        /* TODO */
        super(originalNumber);
    }

    /**
     * Chuyển đổi một số được biểu diễn trong hệ cơ số 10
     * sang số được biểu diễn trong hệ cơ số 2.
     * @param decimal
     * @return xâu ký tự biểu diễn số trong hệ cơ số 2.
     *
     * Yêu cầu: sử dụng thuật toán Euclid để chuyển đổi,
     * không sử dụng thư viện chuyển đổi số có sẵn của Java.
     */
    @Override
    public String decimalTo(String decimal) {
        /* TODO */
        int number = Integer.parseInt(decimal);
        StringBuilder binary = new StringBuilder();

        // Convert decimal to binary using Euclidean division algorithm
        while (number > 0) {
            binary.insert(0, number % 2); // Insert remainder at the beginning
            number /= 2; // Update number for next iteration
        }

        return binary.toString();
    }

    /**
     * Cập nhật số được chuyển đổi khi số ban đầu thay đổi
     * hoặc cơ số của số ban đầu thay đổi. Sau đó in ra terminal
     * số được chuyển đổi theo định dạng a1a2...an(2).
     */
    @Override
    public void update() {
        /* TODO */

        String binary = decimalTo(originalNumber.getNumberPresentation());
        System.out.println("Converted number in binary: " + binary);

    }

    /**
     * Hiển thị số ra terminal theo định dạng a1a2...an(2).
     */
    @Override
    public void display() {
        /* TODO */
        String binary = decimalTo(originalNumber.getNumberPresentation());
        System.out.println("Binary representation: " + binary);

    }

}
