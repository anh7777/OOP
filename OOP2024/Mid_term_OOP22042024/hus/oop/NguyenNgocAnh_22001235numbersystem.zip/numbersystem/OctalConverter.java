package hus.oop.numbersystem;

public class OctalConverter extends AbstractNumberConverter {
    public OctalConverter(OriginalNumber originalNumber) {
        /* TODO */
        super(originalNumber);
    }

    /**
     * Chuyển đổi một số được biểu diễn trong hệ cơ số 10
     * sang số được biểu diễn trong hệ cơ số 8.
     *
     * @param decimal
     * @return xâu ký tự biểu diễn số trong hệ cơ số 8.
     * <p>
     * Yêu cầu: sử dụng thuật toán Euclid để chuyển đổi,
     * không sử dụng thư viện chuyển đổi số có sẵn của Java.
     */
    @Override
    public String decimalTo(String decimal) {
        /* TODO */
        int number = Integer.parseInt(decimal);
        StringBuilder octal = new StringBuilder();

        while (number > 0) {
            int remainder = number % 8;
            octal.insert(0, remainder);
            number /= 8;
        }

        return octal.toString();
    }

    /**
     * Cập nhật số được chuyển đổi khi số ban đầu thay đổi
     * hoặc cơ số của số ban đầu thay đổi. Sau đó in ra terminal
     * số được chuyển đổi theo định dạng a1a2...an(8).
     */
    @Override
    public void update() {
        /* TODO */
        String octal = decimalTo(originalNumber.getNumberPresentation());
        System.out.println("Converted number in octal: " + octal);
    }

    /**
     * Hiển thị số ra terminal theo định dạng a1a2...an(8).
     */
    @Override
    public void display() {
        /* TODO */
        String octal = decimalTo(originalNumber.getNumberPresentation());
        System.out.println("Octal representation: " + octal);
    }
}